<?php

namespace App\Http\Controllers;

use App\Allure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AllureController extends Controller
{
    #listagem
    public function index()
    {
        $allure = Allure::paginate(1);

        return view('allure_index', compact('allure'));
    }


    #view para criação
    public function create()
    {
        return view('allure_create');
    }

    #faz a criação
    public function store(Request $request)
    {
        $allure = new Allure();

        $allure->titulo = $request->titulo;
        $allure->subtitulo = $request->subtitulo;
        $allure->slug = $request->slug;
        $allure->conteudo = $request->conteudo;
        $allure->titulo_seo = $request->titulo_seo;
        $allure->descricao_seo = $request->descricao_seo;
        $allure->save();

        return redirect('allure_index');
    }
    #view para fazer a edição
    public function edit($id)
    {
        $allure = Allure::findOrFail($id);
        return view('allure_edit', compact('allure'));
    }

    #faz o update
    public function update(Request $request, $id)
    {
        $allure = Allure::findOrFail($id);
        $allure->titulo = $request->titulo;
        $allure->subtitulo = $request->subtitulo;
        $allure->slug = $request->slug;
        $allure->conteudo = $request->conteudo;
        $allure->titulo_seo = $request->titulo_seo;
        $allure->descricao_seo = $request->descricao_seo;
        $allure->save();
        return redirect('allure_index');
    }

    #faz o delete
    public function destroy($id)
    {
        $allure = allure::findOrFail($id);
        $allure->delete();
        return redirect('allure_index');
    }
}
