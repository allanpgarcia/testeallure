<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allure extends Model
{
    protected $fillable = [
        'id',
        'titulo',
        'subtitulo',
        'slug',
        'conteudo',
        'titulo_seo',
        'descricao_seo',
    ];

    protected $primaryKey = 'id';
}
