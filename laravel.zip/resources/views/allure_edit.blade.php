@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h4 class="text-center">Edição:</h4>

            <form action="{{ route('update',$allure->id) }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="titulo">Título:</label>
                    <input type="text" class="form-control" id="titulo" name="titulo" value="{{$allure->titulo}}">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="subtitulo">Subtítulo:</label>
                        <input type="text" class="form-control" id="subtitulo" name="subtitulo"
                        value="{{$allure->subtitulo}}" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="slug">Slug:</label>
                        <input type="text" class="form-control" id="slug" name="slug" value="{{$allure->slug}}"/>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="conteudo">Conteúdo:</label>
                        <textarea type="text" class="form-control" id="conteudo" name="conteudo">{{$allure->conteudo}} </textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="titulo_seo">Título SEO:</label>
                        <input type="text" class="form-control" id="titulo_seo" name="titulo_seo"
                        value="{{$allure->titulo_seo}}" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="descricao_seo">Descrição SEO:</label>
                        <textarea type="text" class="form-control" id="descricao_seo" name="descricao_seo"> {{$allure->descricao_seo}}</textarea>
                    </div>
                </div>

                <div class="col-sm-6">
                    <button type="submit" class="btn btn-success">SALVAR</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
