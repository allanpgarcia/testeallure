@extends('layouts.app')

@section('content')
<div class="container fluid">

    <h1>Lista de clientes</h1>

    <div class="row mb-2">
        <div class="col-md-2">

            <a href=" {{ route('create') }}" class="btn btn-block btn-success app-button" role="button"
                aria-pressed="true">
                ADD <i class="fas fa-plus-circle"></i>
            </a>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                <th scope="col">Slug</th>
                <th scope="col" class="text-right">Ação</th>

            </tr>
        </thead>
        <tbody>
            @foreach ($allure as $a)
            <tr>
                <td>{{$a->id}}</td>
                <td>{{$a->titulo}}</td>
                <td>{{$a->subtitulo}}</td>
                <td>{{$a->slug}}</td>
                <td class="text-right">
                    <a role="button" class="btn" href="{{ route('allure_edit', $a->id) }}">
                    <span style="font-size: 2em; color: Tomato;">
                            <i class="far fa-edit"></i>
                    </span>
                    </a>
                    <form action="{{ route('delete', $a->id) }}" method="post"
                            style="display: inline;">
                          @csrf
                          <button class="btn"
                                  style="padding: 0.375rem 0.2rem; color: red; background-color: transparent; vertical-align: unset;">
                              <span style="font-size: 1.375em;">
                              <i class="far fa-times-circle"></i>
                          </span>
                          </button>
                      </form>
                </td>
            </tr>
        </tbody>
        @endforeach
    </table>
</div>
<div class="container">
    {{ $allure->links() }}

</div>

@endsection
