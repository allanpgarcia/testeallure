@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h4 class="text-center">Adicionar novo cliente:</h4>

            <form action="{{ route('store') }}" method="post">
                {{ csrf_field() }}
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="title">Título:</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Digite aqui..">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Subtítulo:</label>
                        <input type="text" class="form-control" id="subtitulo" name="subtitulo"
                            placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Slug:</label>
                        <input type="text" class="form-control" id="slug" name="slug" placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Conteúdo:</label>
                        <textarea type="text" class="form-control" id="conteudo" name="conteudo"
                            placeholder="Digite aqui.."> </textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Título SEO:</label>
                        <input type="text" class="form-control" id="titulo_seo" name="titulo_seo"
                            placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Descrição SEO:</label>
                        <textarea type="text" class="form-control" id="descricao_seo" name="descricao_seo"
                            placeholder="Digite aqui.."></textarea>
                    </div>
                </div>

                <div class="col-sm-6">
                    <button type="submit" class="btn btn-success">CADASTRAR</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
