<?php $__env->startSection('content'); ?>
<div class="container fluid">

    <h1>Lista de clientes</h1>

    <div class="row mb-2">
        <div class="col-md-2">

            <a href=" <?php echo e(route('create')); ?>" class="btn btn-block btn-success app-button" role="button"
                aria-pressed="true">
                ADD <i class="fas fa-plus-circle"></i>
            </a>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">id</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                <th scope="col">Slug</th>
                <th scope="col" class="text-right">Ação</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $allure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($a->id); ?></td>
                <td><?php echo e($a->titulo); ?></td>
                <td><?php echo e($a->subtitulo); ?></td>
                <td><?php echo e($a->slug); ?></td>
                <td class="text-right">
                    <a role="button" class="btn" href="<?php echo e(route('allure_edit', $a->id)); ?>">
                    <span style="font-size: 2em; color: Tomato;">
                            <i class="far fa-edit"></i>
                    </span>
                    </a>
                    <form action="<?php echo e(route('delete', $a->id)); ?>" method="post"
                            style="display: inline;">
                          <?php echo csrf_field(); ?>
                          <button class="btn"
                                  style="padding: 0.375rem 0.2rem; color: red; background-color: transparent; vertical-align: unset;">
                              <span style="font-size: 1.375em;">
                              <i class="far fa-times-circle"></i>
                          </span>
                          </button>
                      </form>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div class="container">
    <?php echo e($allure->links()); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/teste/resources/views/allure_index.blade.php ENDPATH**/ ?>