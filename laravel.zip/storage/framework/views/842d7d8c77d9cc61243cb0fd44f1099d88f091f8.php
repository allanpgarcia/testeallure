<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h4 class="text-center">Adicionar novo cliente:</h4>

            <form action="<?php echo e(route('store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="title">Título:</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Digite aqui..">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Subtítulo:</label>
                        <input type="text" class="form-control" id="subtitulo" name="subtitulo"
                            placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Slug:</label>
                        <input type="text" class="form-control" id="slug" name="slug" placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Conteúdo:</label>
                        <textarea type="text" class="form-control" id="conteudo" name="conteudo"
                            placeholder="Digite aqui.."> </textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Título SEO:</label>
                        <input type="text" class="form-control" id="titulo_seo" name="titulo_seo"
                            placeholder="Digite aqui.." />
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-6">
                        <label for="description">Descrição SEO:</label>
                        <textarea type="text" class="form-control" id="descricao_seo" name="descricao_seo"
                            placeholder="Digite aqui.."></textarea>
                    </div>
                </div>

                <div class="col-sm-6">
                    <button type="submit" class="btn btn-success">CADASTRAR</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/teste/resources/views/allure_create.blade.php ENDPATH**/ ?>